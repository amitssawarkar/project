﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
public partial class users_SendRequest : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        con = new SqlConnection(ConfigurationManager.AppSettings["LIS"]);

        cmd = new SqlCommand();
        con.Open();
        cmd.Connection = con;
        cmd.CommandText = "Insert into Request(reqfrom,reqto,reqfor,regdate,status) values(@reqfrom,@reqto,@reqfor,@regdate,@status) ";

        cmd.Parameters.AddWithValue("@reqfrom",Session["userid"].ToString());
        cmd.Parameters.AddWithValue("@reqto", Request.QueryString["username"].ToString());
        cmd.Parameters.AddWithValue("@reqfor", Request.QueryString["for"].ToString());
        cmd.Parameters.AddWithValue("@regdate",DateTime.Now.ToString());
        cmd.Parameters.AddWithValue("@status","Pending");

        cmd.Connection = con;
        
        int n=cmd.ExecuteNonQuery();
        if (n > 0)
        {
            lblmsg.Text = "Your Request Transfered To Administrator. Administrator shortly contact you !";
        }
        else
        {
            lblmsg.Text = "Request not processed !";
        }

        con.Close();
        

    }
}