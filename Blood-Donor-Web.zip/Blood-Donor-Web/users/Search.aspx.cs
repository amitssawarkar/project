﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class users_Search : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Response.Redirect("SendRequest.aspx?username=" + GridView1.SelectedRow.Cells[1].Text+"&for="+ Server.UrlEncode(GridView1.SelectedRow.Cells[5].Text));
            
    }
    protected void btnSearchBlood_Click(object sender, EventArgs e)
    {

        string q = "SELECT [username],[id], [name], [city], [blood_group], [photo],mobile FROM [Registration] where blood_group='" + ddlBlood.SelectedItem.Value.ToString() + "' and username <> '" + Session["userid"].ToString() + "'";

        SqlDataSearch.SelectCommand = q;
    }
   
}