﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class admin_ViewDetails : System.Web.UI.Page
{
    BasicCode b = new BasicCode();
    string reqid, donorname, receivername;
    protected void Page_Load(object sender, EventArgs e)
    {
      

        reqid = Request.QueryString["reqid"].ToString();
        donorname = Request.QueryString["reqto"].ToString();
        receivername = Request.QueryString["reqfrom"].ToString();

        string q1 = "SELECT [id], [name], [city], [mobile], [email], [photo], [blood_group] FROM [Registration] where username='" + donorname + "'";
        SqlDataDonorData.SelectCommand = q1;


        string q2 = "SELECT [id], [name], [city], [mobile], [email], [photo], [blood_group] FROM [Registration] where username='" + receivername + "'";
        SqlDataReceiverData.SelectCommand = q2;

    }
    protected void btnConfirm_Click(object sender, EventArgs e)
    {
        string name, city, donor_mobile, receiver_mobile, blood_group, receiver_email;
        name = GridView1.Rows[0].Cells[1].Text;
        city = GridView1.Rows[0].Cells[2].Text;
        donor_mobile = GridView1.Rows[0].Cells[3].Text;
        receiver_mobile = GridView2.Rows[0].Cells[3].Text;
        receiver_email = GridView2.Rows[0].Cells[4].Text;
        blood_group =Server.UrlEncode(GridView1.Rows[0].Cells[6].Text);

        string msg = "Dear " + receivername + ",The Blood Doner Details are, Name: " + name + " city: " + city + " mobile: " + donor_mobile + " Blood: " + blood_group;

       // b.SendSms("SMARTD", receiver_mobile, msg);

        try
        {

            b.send(receiver_email, "Donor Details", msg);

            setStatus("Complete"); // status to complete the request
            lblmsg.Text = "The Request Processed Successfully !";
            Response.Redirect("EmailSuccess.aspx");
        }
        catch (Exception er)
        {

            Response.Redirect("EmailSuccess.aspx");
        }
    }
    protected void btnReject_Click(object sender, EventArgs e)
    {
        //string receiver_mobile = GridView2.Rows[0].Cells[3].Text;
        string receiver_email = GridView2.Rows[0].Cells[4].Text;
       // b.SendSms("SMARTD", receiver_mobile, "Dear " + receivername + ", the requested doner not ready for blood donation. Sorry for your inconvenience. Thank You.");
        string msg = "Dear User, the requested doner not ready for blood donation. Sorry for your inconvenience. Thank You.";
        setStatus("Reject"); // status to request rejected
        
        try
        {

        b.send(receiver_email, "Donor Details", msg); 

        lblmsg.Text = "The Request is Rejected !";
        Response.Redirect("EmailSuccess.aspx");

        }
        catch (Exception er)
        {

            Response.Redirect("EmailSuccess.aspx");
        }
    }

    protected void setStatus(string status)
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        con = new SqlConnection(ConfigurationManager.AppSettings["LIS"]);
        cmd = new SqlCommand();
        con.Open();
        cmd.Connection = con;
        cmd.CommandText = "Update Request set status=@status where rid=@rid";
        cmd.Parameters.AddWithValue("@status", status);
        cmd.Parameters.AddWithValue("@rid", Request.QueryString["reqid"].ToString());
        cmd.Connection = con;
        int n = cmd.ExecuteNonQuery();
        con.Close();

    }

}